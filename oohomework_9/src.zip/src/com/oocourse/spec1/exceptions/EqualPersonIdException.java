package com.oocourse.spec1.exceptions;

public abstract class EqualPersonIdException extends Exception {

    public abstract void print();
}
